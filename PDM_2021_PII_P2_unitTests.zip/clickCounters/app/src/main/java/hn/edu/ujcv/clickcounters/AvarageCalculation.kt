package hn.edu.ujcv.clickcounters

object AvarageCalculation {

    fun avarage (counter:Int):Float{
        var result = counter/1000
        return result.toFloat();
    }

}